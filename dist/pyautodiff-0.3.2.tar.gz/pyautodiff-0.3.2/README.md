# cs207-FinalProject
Group 2

Phoebe Wong

Pat Sukhum

Benedikt Groever

Maleah Fekete

[![Build Status](https://travis-ci.com/CS207-group2/cs207-FinalProject.svg?branch=master)](https://travis-ci.com/CS207-group2/cs207-FinalProject.svg?branch=master)

[![Coverage Status](https://coveralls.io/repos/github/CS207-group2/cs207-FinalProject/badge.svg?branch=travis)](https://coveralls.io/github/CS207-group2/cs207-FinalProject?branch=travis)

# Autodiff

[Click here to read the docs](docs/README.md)
