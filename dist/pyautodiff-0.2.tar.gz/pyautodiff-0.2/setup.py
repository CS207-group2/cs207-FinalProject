from setuptools import setup, find_packages
setup(
    name="pyautodiff",
    version="0.2",
    packages=find_packages('pyautodiff'),
    package_dir={"":"pyautodiff"}
)
